import pymysql
import json
import os

# Fetch the database connection details from environment variables
db_host = os.environ['db-hotelproject.c5sc46wkkcnc.us-east-1.rds.amazonaws.com']
db_user = os.environ['admin']
db_password = os.environ['hotelProject1']
db_name = os.environ['db-1hotelProject']

def get_db_connection():
    """Create and return a database connection"""
    return pymysql.connect(
        host=db_host,
        user=db_user,
        password=db_password,
        database=db_name
    )

def lambda_handler(event, context):
    print("Received event:", json.dumps(event))
    
    # Get the intent name
    if 'currentIntent' not in event:
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": "Invalid request format."
                }
            }
        }
    
    intent = event['currentIntent']['name']
    connection = None
    
    try:
        # Establish database connection
        connection = get_db_connection()
        cursor = connection.cursor()

        # Route the request based on the intent
        if intent == "bookRoom":
            return handle_booking(event, cursor, connection)
        elif intent == "modifyBooking":
            return handle_modification(event, cursor, connection)
        elif intent == "cancelRoom":
            return handle_cancellation(event, cursor, connection)
        else:
            return {
                "dialogAction": {
                    "type": "Close",
                    "fulfillmentState": "Failed",
                    "message": {
                        "contentType": "PlainText",
                        "content": "Unknown intent. Please try again."
                    }
                }
            }
    except pymysql.Error as e:
        print(f"Database error: {e}")
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": "Database error occurred. Please try again later."
                }
            }
        }
    except Exception as e:
        print(f"General error: {e}")
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": "There was an error processing your request."
                }
            }
        }
    finally:
        if connection:
            connection.close()

# [Rest of the handler functions remain the same]
def handle_booking(event, cursor, connection):
    slots = event['currentIntent']['slots']
    first_name = slots['FirstName']
    last_name = slots['LastName']
    email = slots['Email']
    phone_number = slots['PhoneNumber']
    room_type = slots['RoomType']
    check_in_date = slots['CheckInDate']
    check_out_date = slots['CheckOutDate']

    # Check if room is available for the selected room type
    cursor.execute("""
        SELECT r.room_id 
    FROM rooms r
    JOIN room_type rt ON r.room_type_id = rt.room_type_id
    WHERE rt.room_type_name = %s AND r.is_available = TRUE
    LIMIT 1
    """, (room_type,))
    room = cursor.fetchone()

    if not room:
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": f"Sorry, no {room_type} rooms are available."
                }
            }
        }

    room_id = room[0]

    try:
        # Insert guest details into Guest table
        cursor.execute("""
            INSERT INTO Guest (first_name, last_name, email, phone_number)
            VALUES (%s, %s, %s, %s)
        """, (first_name, last_name, email, phone_number))
        guest_id = cursor.lastrowid

        # Insert booking details into Booking table
        cursor.execute("""
            INSERT INTO Booking (guest_id, room_id, check_in_date, check_out_date, booking_status)
            VALUES (%s, %s, %s, %s, 'Booked')
        """, (guest_id, room_id, check_in_date, check_out_date))

        # Update room availability
        cursor.execute("UPDATE rooms SET is_available = FALSE WHERE room_id = %s", (room_id,))
        connection.commit()

        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Fulfilled",
                "message": {
                    "contentType": "PlainText",
                    "content": f"Room booked successfully for {first_name} {last_name}. Your check-in date is {check_in_date}."
                }
            }
        }
    except:
        connection.rollback()
        raise

# [handle_modification and handle_cancellation functions remain the same]


# Handle Modification Intent
def handle_modification(event, cursor, connection):
    slots = event['currentIntent']['slots']
    first_name = slots['FirstName']
    last_name = slots['LastName']
    email = slots['Email']
    new_check_in_date = slots['NewCheckInDate']
    new_check_out_date = slots['NewCheckOutDate']
    new_room_type = slots['NewRoomType']

    # Find existing booking for the guest
    cursor.execute("""
        SELECT b.booking_id, b.room_id
        FROM Booking b
        JOIN Guest g ON b.guest_id = g.guest_id
        WHERE g.first_name = %s AND g.last_name = %s AND g.email = %s AND b.booking_status = 'Booked'
    """, (first_name, last_name, email))
    booking = cursor.fetchone()

    if not booking:
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": "No booking found for the given details."
                }
            }
        }

    booking_id, old_room_id = booking

    # Check availability of new room type
    cursor.execute("""
        SELECT r.room_id 
    FROM rooms r
    JOIN room_type rt ON r.room_type_id = rt.room_type_id
    WHERE rt.room_type_name = %s AND r.is_available = TRUE
    LIMIT 1
    """, (new_room_type,))
    new_room = cursor.fetchone()

    if not new_room:
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": f"Sorry, no {new_room_type} rooms are available."
                }
            }
        }

    new_room_id = new_room[0]

    # Update the booking
    cursor.execute("""
        UPDATE Booking 
        SET room_id = %s, check_in_date = %s, check_out_date = %s
        WHERE booking_id = %s
    """, (new_room_id, new_check_in_date, new_check_out_date, booking_id))

    # Update room availability
    cursor.execute("UPDATE rooms SET is_available = TRUE WHERE room_id = %s", (old_room_id,))
    cursor.execute("UPDATE rooms SET is_available = FALSE WHERE room_id = %s", (new_room_id,))
    connection.commit()

    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": "Booking modified successfully."
            }
        }
    }

def handle_cancellation(event, cursor, connection):
    slots = event['currentIntent']['slots']
    first_name = slots['FirstName']
    last_name = slots['LastName']
    email = slots['Email']
    check_in_date = slots['CheckInDate']

    # Fetch the booking to cancel
    cursor.execute("""
        SELECT b.booking_id, b.room_id
        FROM Booking b
        JOIN Guest g ON b.guest_id = g.guest_id
        WHERE g.first_name = %s AND g.last_name = %s AND g.email = %s AND b.check_in_date = %s
    """, (first_name, last_name, email, check_in_date))
    booking = cursor.fetchone()

    if not booking:
        return {
            "dialogAction": {
                "type": "Close",
                "fulfillmentState": "Failed",
                "message": {
                    "contentType": "PlainText",
                    "content": "No booking found for the given details."
                }
            }
        }

    booking_id, room_id = booking

    # Cancel the booking
    cursor.execute("UPDATE Booking SET booking_status = 'Cancelled' WHERE booking_id = %s", (booking_id,))
    
    # Update room availability
    cursor.execute("UPDATE rooms SET is_available = TRUE WHERE room_id = %s", (room_id,))

    connection.commit()

    return {
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": "Fulfilled",
            "message": {
                "contentType": "PlainText",
                "content": f"Your booking has been successfully cancelled."
            }
        }
    }

